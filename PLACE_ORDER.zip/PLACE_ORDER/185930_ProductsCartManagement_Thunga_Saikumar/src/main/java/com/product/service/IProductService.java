package com.product.service;

import java.util.List;

import com.product.bean.Product;
import com.product.exception.ProductException;

public interface IProductService {

	public List<Product> createProduct(Product pro) throws ProductException;
	public Product getProductById(int id) throws ProductException;
	public void deleteProduct (int id) throws ProductException;
	public List<Product> getAllProducts() throws ProductException;
	public List<Product> updateProduct(int id, Product bo) throws ProductException;
	
	
}
