package com.product.bean;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;

@Entity
public class Product implements Serializable {
	
	@Id	
	private int id;
	private String custname;
	private String custaddress;
	private String custstate;
	private long phone;
	private int withindays;
	private int price;
	private String status;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getCustname() {
		return custname;
	}
	public void setCustname(String custname) {
		this.custname = custname;
	}
	public String getCustaddress() {
		return custaddress;
	}
	public void setCustaddress(String custaddress) {
		this.custaddress = custaddress;
	}
	public String getCuststate() {
		return custstate;
	}
	public void setCuststate(String custstate) {
		this.custstate = custstate;
	}
	public long getPhone() {
		return phone;
	}
	public void setPhone(long phone) {
		this.phone = phone;
	}
	public int getWithindays() {
		return withindays;
	}
	public void setWithindays(int withindays) {
		this.withindays = withindays;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	@Override
	public String toString() {
		return "Product [id=" + id + ", custname=" + custname + ", custaddress=" + custaddress + ", custstate="
				+ custstate + ", phone=" + phone + ", withindays=" + withindays + ", price=" + price + ", status="
				+ status + "]";
	}
	

}
