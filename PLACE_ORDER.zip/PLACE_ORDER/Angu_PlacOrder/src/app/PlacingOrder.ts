export class PlacingOrder{
    id:number;
    custname:string;
    custaddress:string;
    custstate:string;
    phone:number;
    withindays:number;
    price:number;
    status:string;
    }