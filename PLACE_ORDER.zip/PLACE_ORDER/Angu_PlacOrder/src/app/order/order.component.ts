import { Component, OnInit } from '@angular/core';
import { PlacingService } from '../placing.service';
import { PlacingOrder } from '../PlacingOrder';

@Component({
  selector: 'app-order',
  templateUrl: './order.component.html',
  styleUrls: ['./order.component.css']
})
export class OrderComponent implements OnInit {

  placingorder:PlacingOrder;
  constructor(private placingService:PlacingService) { 
  //this.orderList= this.placingService.orderList;
   
  }
  
  ngOnInit() {
    this.show();
    
  }
  show()
  {
    this.placingService.show().subscribe(data=>(this.placingorder=data));
  }
  reload(){
    this.show();
  }

  flag=false;
  id;custname;custaddress;custstate;phone;withindays;price;status

bo:PlacingOrder=new PlacingOrder;
  changeFlag(b:PlacingOrder){
    this.flag=true;
    this.id=b.id;
    this.custname=b.custname;
    this.custaddress=b.custaddress;
    this.custstate=b.custstate;
    this.phone=b.phone;
    this.withindays=b.withindays;
    this.price=b.price;
    this.status=b.status;

  }
   update(data){
    let b:PlacingOrder=new PlacingOrder;
   console.log(data);
   this.placingService.update(data).subscribe(data=>(this.placingorder=data));
   alert("Updated successfully");
  }
}